# 😄 Tailwind CSS Multi Level Dropdown Menu

```
Note :- Modified the CSS Classes for the styling of the component.

This Code is the updated version of the Tutorial
```

## 😃 Click here for the 👉 [💥LIVE DEMO](https://frontendfunn.github.io/Tailwindcss-multi-leveldropdown/)

---

![preview](images/preview.gif)

# 👉 Subscribe to My Channel [💙❤️Youtube❤️💙](https://www.youtube.com/channel/UCpOHt5d6GG-mvo-_pU06rhQ?sub_confirmation=1)

Made with ❤️ - by [FrontEndFunn](https://www.youtube.com/channel/UCpOHt5d6GG-mvo-_pU06rhQ?sub_confirmation=1)
